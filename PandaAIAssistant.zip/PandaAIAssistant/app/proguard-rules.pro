# Add project-specific ProGuard rules here.
# By default, the rules in this file are blank.
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard/index.html
