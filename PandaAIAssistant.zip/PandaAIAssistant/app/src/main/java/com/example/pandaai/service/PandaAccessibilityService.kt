package com.example.pandaai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PandaAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Handle accessibility events here
    }

    override fun onInterrupt() {}

    fun performGlobalAction(action: Int) {
        performGlobalAction(action)
    }

    fun findNodeByText(text: String): AccessibilityNodeInfo? {
        val rootNode = rootInActiveWindow ?: return null
        val nodes = rootNode.findAccessibilityNodeInfosByText(text)
        return nodes.firstOrNull()
    }

    fun tapNode(node: AccessibilityNodeInfo): Boolean {
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    fun tapAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 100))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun scrollDown() {
        val rootNode = rootInActiveWindow ?: return
        rootNode.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    fun getScreenContent(): String {
        val rootNode = rootInActiveWindow ?: return ""
        val content = StringBuilder()
        traverseNodes(rootNode, content)
        return content.toString()
    }

    private fun traverseNodes(node: AccessibilityNodeInfo, content: StringBuilder) {
        node.text?.let { content.append(it).append(" ") }
        node.contentDescription?.let { content.append(it).append(" ") }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { traverseNodes(it, content) }
        }
    }
}
