package com.example.pandaai.api

import com.example.pandaai.model.ChatRequest
import com.example.pandaai.model.ChatResponse
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url

interface AiApiService {
    @POST
    suspend fun getChatCompletion(
        @Url url: String,
        @Header("Authorization") apiKey: String,
        @Body request: ChatRequest
    ): ChatResponse
}
