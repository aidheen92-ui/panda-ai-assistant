package com.example.pandaai.model

enum class AiProvider {
    OPENAI,
    QWEN,
    GEMINI,
    CUSTOM
}

data class ChatMessage(
    val role: String,
    val content: String
)

data class ChatRequest(
    val model: String,
    val messages: List<ChatMessage>,
    val temperature: Double = 0.7
)

data class ChatResponse(
    val choices: List<Choice>
)

data class Choice(
    val message: ChatMessage
)
