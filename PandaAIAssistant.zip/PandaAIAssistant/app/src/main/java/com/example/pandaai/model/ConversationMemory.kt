package com.example.pandaai.model

import java.util.LinkedList

class ConversationMemory(private val maxMessages: Int = 10) {
    private val history: LinkedList<ChatMessage> = LinkedList()

    fun addMessage(role: String, content: String) {
        if (history.size >= maxMessages) {
            history.removeFirst()
        }
        history.add(ChatMessage(role, content))
    }

    fun getHistory(): List<ChatMessage> {
        return history.toList()
    }

    fun clearHistory() {
        history.clear()
    }
}
