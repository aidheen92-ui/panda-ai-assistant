package com.example.pandaai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.pandaai.R
import com.example.pandaai.api.AiEngine
import com.example.pandaai.automation.AutomationEngine
import com.example.pandaai.model.AiProvider
import com.example.pandaai.model.ConversationMemory
import com.example.pandaai.voice.VoiceManager
import com.example.pandaai.voice.WakeWordDetector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainAssistantService : Service(), WakeWordDetector.WakeWordListener, VoiceManager.VoiceListener {

    private lateinit var wakeWordDetector: WakeWordDetector
    private lateinit var voiceManager: VoiceManager
    private lateinit var aiEngine: AiEngine
    private lateinit var automationEngine: AutomationEngine
    private val conversationMemory = ConversationMemory()
    private val serviceScope = CoroutineScope(Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel()
        val notification = createNotification()
        startForeground(1, notification)

        wakeWordDetector = WakeWordDetector(this, "Hey Assistant", this)
        voiceManager = VoiceManager(this, this)
        aiEngine = AiEngine(this)
        automationEngine = AutomationEngine(this, null)

        wakeWordDetector.startListening()
    }

    override fun onWakeWordDetected() {
        wakeWordDetector.stopListening()
        voiceManager.speak("How can I help you?")
        voiceManager.startListening()
    }

    override fun onSpeechResult(text: String) {
        serviceScope.launch {
            conversationMemory.addMessage("user", text)
            val response = aiEngine.generateResponse(
                AiProvider.OPENAI,
                "your_api_key",
                null,
                "gpt-3.5-turbo",
                conversationMemory.getHistory()
            )
            conversationMemory.addMessage("assistant", response)
            voiceManager.speak(response)
            
            // Check for automation commands
            automationEngine.executeCommand(text)
            
            wakeWordDetector.startListening()
        }
    }

    override fun onError(error: String) {
        wakeWordDetector.startListening()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                "PandaAssistantChannel",
                "Panda AI Assistant Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(serviceChannel)
        }
    }

    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, "PandaAssistantChannel")
            .setContentTitle("Panda AI Assistant")
            .setContentText("Running in background...")
            .setSmallIcon(R.mipmap.ic_launcher)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        wakeWordDetector.shutdown()
        voiceManager.shutdown()
    }
}
