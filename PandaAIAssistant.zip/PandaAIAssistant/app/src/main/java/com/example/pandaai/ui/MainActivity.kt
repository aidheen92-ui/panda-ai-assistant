package com.example.pandaai.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.pandaai.R
import com.example.pandaai.service.MainAssistantService

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var micButton: Button
    private lateinit var settingsButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.status_text)
        micButton = findViewById(R.id.mic_button)
        settingsButton = findViewById(R.id.settings_button)

        micButton.setOnClickListener {
            // Activate assistant
        }

        settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        startService(Intent(this, MainAssistantService::class.java))
    }
}
