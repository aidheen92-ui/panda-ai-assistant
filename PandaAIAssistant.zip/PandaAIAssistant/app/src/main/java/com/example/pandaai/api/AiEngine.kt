package com.example.pandaai.api

import android.content.Context
import com.example.pandaai.model.AiProvider
import com.example.pandaai.model.ChatMessage
import com.example.pandaai.model.ChatRequest
import retrofit2.Retrofit
import retrofit2.converter.gson:GsonConverterFactory

class AiEngine(private val context: Context) {
    private val apiService: AiApiService

    init {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.openai.com/") // Default base URL
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        apiService = retrofit.create(AiApiService::class.java)
    }

    suspend fun generateResponse(
        provider: AiProvider,
        apiKey: String,
        customUrl: String?,
        modelName: String,
        messages: List<ChatMessage>
    ): String {
        val url = when (provider) {
            AiProvider.OPENAI -> "v1/chat/completions"
            AiProvider.QWEN -> customUrl ?: "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation"
            AiProvider.GEMINI -> "v1beta/models/$modelName:generateContent"
            AiProvider.CUSTOM -> customUrl ?: ""
        }

        val request = ChatRequest(model = modelName, messages = messages)
        
        return try {
            val response = apiService.getChatCompletion(url, "Bearer $apiKey", request)
            response.choices.firstOrNull()?.message?.content ?: "No response from AI."
        } catch (e: Exception) {
            "Error: ${e.localizedMessage}"
        }
    }
}
