# Panda AI Assistant

A fully functional Android AI assistant similar to Panda AI.

## Features

- **AI Core**: Supports multiple AI providers (OpenAI, Qwen, Gemini, etc.) with API key management.
- **Voice System**: Wake word activation, STT, and TTS for natural conversation.
- **Accessibility Control**: UI automation and device control using Accessibility Service.
- **Task Automation**: Multi-step automation for opening apps, playing music, etc.
- **Floating Assistant**: Optional floating bubble for quick access.
- **Background Operation**: Runs as a foreground service for continuous operation.

## Getting Started

1.  **Clone the repository**: `git clone https://github.com/example/panda-ai-assistant.git`
2.  **Open in Android Studio**: Open the `PandaAIAssistant` folder in Android Studio.
3.  **Set up API Keys**: Enter your API keys in the app's settings screen.
4.  **Enable Accessibility Service**: Enable the "Panda AI Assistant" service in your device's accessibility settings.
5.  **Build and Run**: Build the project and run it on your Android device.

## Requirements

- Android 8.0 (API 26) or higher.
- Internet connection for AI API calls.
- Microphone permission for voice commands.
- Accessibility service permission for UI automation.
- Overlay permission for floating bubble.

## License

This project is licensed under the MIT License.
